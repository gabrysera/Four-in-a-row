from __future__ import annotations
import sys
from ..Tree.Tree import Tree
from ..Board import Board
from ..Heuristic.Heuristic import Heuristic

class AlphaBetaTree(Tree):

    def __init__(self, board:Board, depth:int, playerId:int, heuristic:Heuristic, evaluationPlayer:int, gameN:int, alpha:int, beta:int):
        self.alpha = alpha
        self.beta = beta
        super().__init__(board, depth, playerId, heuristic, evaluationPlayer, gameN)
        

    def getValueAndMove(self) -> tuple(int, int):
        childrenValues:list(int) = self.getChildrenValues(self.getChildren())
        print(childrenValues)
        if self.playerId == self.evaluationPlayer:
            maxValue = max(childrenValues, key=lambda x: x[0])
            return maxValue
        else:
            minValue = min(childrenValues, key=lambda x: x[0])
            return minValue

    def getChildren(self) -> list('Tree'):
        #HERE IMPLEMENT ALPHA BETA PRUNING
        children = []
        nextPlayer = 1 if self.evaluationPlayer == 2 else 2 
        #if this player is max player
        if self.playerId == self.evaluationPlayer:
            bestValue = -sys.maxsize-1
            for col in range(0, self.board.width):
                if self.board.isValid(col):
                    newTree = AlphaBetaTree(self.board.getNewBoard(col, self.evaluationPlayer), self.depth-1, self.playerId, self.heuristic, nextPlayer, self.gameN, self.alpha, self.beta)
                    value = newTree.value
                    bestValue = max( bestValue, value) 
                    self.alpha = max( self.alpha, bestValue)
                    newTree.value = bestValue
                    children.append((newTree, col))
                    if self.beta <= self.alpha:
                        break
            return children
        else:
            bestValue = sys.maxsize
            for col in range(0, self.board.width): #[0..6]
                if self.board.isValid(col):
                    newTree = AlphaBetaTree(self.board.getNewBoard(col, self.evaluationPlayer), self.depth-1, self.playerId, self.heuristic, nextPlayer, self.gameN, self.alpha, self.beta)
                    value = newTree.value
                    bestValue = min( bestValue, value) 
                    self.beta = min( self.beta, bestValue)
                    newTree.value = bestValue
                    children.append((newTree, col))
                    if self.beta <= self.alpha:
                        break
            return children
    