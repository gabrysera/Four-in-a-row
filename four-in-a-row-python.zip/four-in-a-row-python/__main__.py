from .NRow.App import App



if __name__ == "__main__":
    app = App()
